//
//  ViewController.m
//  googleSample
//
//  Created by Uday on 15/09/17.
//  Copyright © 2017 rutherford.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [GIDSignIn sharedInstance].delegate=self;
    [GIDSignIn sharedInstance].uiDelegate=self;
    
    
    
//    NSString * key= @"demo";
//     NSString * secret= @"textToEncript";
//    NSData *plain = [secret dataUsingEncoding:NSUTF8StringEncoding];
//    NSData *cipher = [plain AES256EncryptWithKey:key];
//    printf("%s\n", [[cipher description] UTF8String]);
//    plain = [cipher AES256DecryptWithKey:key]; printf("%s\n", [[plain description] UTF8String]);
//    printf("%s\n", [[[NSString alloc] initWithData:plain encoding:NSUTF8StringEncoding] UTF8String]);
    
    // Do any additional setup after loading the view, typically from a nib.
}


// Present a view that prompts the user to sign in with Google
- (void)signIn:(GIDSignIn *)signIn
presentViewController:(UIViewController *)viewController {
    [self presentViewController:viewController animated:YES completion:nil];
    
}
- (void)signInWillDispatch:(GIDSignIn *)signIn error:(NSError *)error {
    
}
// Dismiss the "Sign in with Google" view
- (void)signIn:(GIDSignIn *)signIn
dismissViewController:(UIViewController *)viewController {
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)didTapSignIn:(id)sender
{
   [[GIDSignIn sharedInstance] signIn];
}
- (IBAction)didTapSignOut:(id)sender {
    [[GIDSignIn sharedInstance] signOut];
}
- (void)signIn:(GIDSignIn *)signIn didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error
{
    //user signed in
    
    NSLog(@"%@",user.userID);
    NSLog(@"%@",user.authentication.idToken);
    NSLog(@"%@",user.profile.name);
    NSLog(@"%@",user.profile.givenName);
    NSLog(@"%@",user.profile.familyName);
    NSLog(@"%@",user.profile.email);
    NSLog(@"%@",user.authentication.accessToken);
    NSLog(@"%@",user.profile);
    
    
    //get user data in "user" (GIDGoogleUser object)
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
   
    NSLog(@"verifier %@",data);}
@end
